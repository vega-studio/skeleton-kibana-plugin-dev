# diamond-chart

> A chart showing an intersection of services with other services to report status events

---

## NOTES

This is the plugin structure that will be compiled into a plugin to be injected into kibana. It is not the intent for
this to be the primary form of development for the UI that goes into this plugin. This plugin is present merely to
develop the interfacing necessary to work with kibana.

The bundles that will be generated that the plugin will be injected into `public/lib`.
