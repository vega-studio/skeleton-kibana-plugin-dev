export default function (kibana) {
  return new kibana.Plugin({
    require: ['elasticsearch', 'canvas'],
    name: 'diamond-chart',
    uiExports: {
      visTypes: [
        'plugins/diamond-chart/vis-registry'
      ],
      canvas: [
        'plugins/diamond-chart/index'
      ]
    }
  });
}
